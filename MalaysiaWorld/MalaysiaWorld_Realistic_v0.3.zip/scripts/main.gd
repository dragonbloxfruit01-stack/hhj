extends Node3D

const PLAYER_SCENE = preload("res://scenes/Player.tscn")
const PORT := 7777
const MAX_PLAYERS := 20

var players: Dictionary = {}
var mobile_move := Vector2.ZERO
var joy_center := Vector2(82, 82)
var joy_id := -1
var joy_radius := 62.0
var money := 2500
var near_cafe := false
var cafe_open := false
var stock := 12
var customers := 0
var income := 0
var business_clock := 0.0
var time_clock := 0.0
var is_rainy := false
var peer := ENetMultiplayerPeer.new()
var ui: CanvasLayer
var status_label: Label
var money_label: Label
var cafe_label: Label
var address_field: LineEdit
var joy_knob: ColorRect

func _ready() -> void:
    _make_environment()
    _make_kuala_lumpur_block()
    _make_ui()
    multiplayer.peer_connected.connect(_peer_connected)
    multiplayer.peer_disconnected.connect(_peer_disconnected)
    _spawn_player(multiplayer.get_unique_id(), true)

func _process(delta: float) -> void:
    time_clock += delta
    _update_daylight()
    if cafe_open and stock > 0:
        business_clock += delta
        if business_clock >= 10.0:
            business_clock = 0.0
            stock -= 1
            customers += 1
            income += 10
            money += 10
            _refresh_money()
    else:
        business_clock = 0.0

func _make_environment() -> void:
    var env_node := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_SKY
    var sky := Sky.new()
    var sky_mat := ProceduralSkyMaterial.new()
    sky_mat.sky_top_color = Color(0.11, 0.20, 0.32)
    sky_mat.sky_horizon_color = Color(0.82, 0.55, 0.36)
    sky_mat.ground_bottom_color = Color(0.10, 0.12, 0.14)
    sky_mat.ground_horizon_color = Color(0.38, 0.34, 0.31)
    sky.sky_material = sky_mat
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
    env.ambient_light_energy = 0.65
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env.tonemap_exposure = 1.0
    env.fog_enabled = true
    env.fog_light_color = Color(0.52, 0.57, 0.62)
    env.fog_density = 0.0018
    env_node.environment = env
    add_child(env_node)

    var sun := DirectionalLight3D.new()
    sun.name = "Sun"
    sun.rotation_degrees = Vector3(-35, -28, 0)
    sun.light_energy = 1.25
    sun.shadow_enabled = true
    sun.directional_shadow_max_distance = 90.0
    add_child(sun)

func _update_daylight() -> void:
    var sun := get_node_or_null("Sun") as DirectionalLight3D
    if sun:
        var phase := fposmod(time_clock / 180.0, 1.0)
        sun.rotation_degrees.x = -10.0 - 55.0 * sin(phase * TAU)
        sun.light_energy = 0.25 + 1.0 * max(0.0, sin(phase * TAU))
        if phase > 0.68 or phase < 0.12:
            sun.light_color = Color(1.0, 0.68, 0.48)
        else:
            sun.light_color = Color(1.0, 0.94, 0.82)

func _mat(color: Color, rough := 0.8, metal := 0.0) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = color
    m.roughness = rough
    m.metallic = metal
    return m

func _static_box(name: String, pos: Vector3, size: Vector3, material: Material, collision := true) -> StaticBody3D:
    var body := StaticBody3D.new()
    body.name = name
    body.position = pos
    var mesh := BoxMesh.new()
    mesh.size = size
    var instance := MeshInstance3D.new()
    instance.mesh = mesh
    instance.material_override = material
    body.add_child(instance)
    if collision:
        var shape := CollisionShape3D.new()
        var box := BoxShape3D.new()
        box.size = size
        shape.shape = box
        body.add_child(shape)
    add_child(body)
    return body

func _make_kuala_lumpur_block() -> void:
    var asphalt := _mat(Color(0.075,0.085,0.095),0.34,0.12)
    var wet_asphalt := _mat(Color(0.10,0.12,0.14),0.18,0.28)
    var concrete := _mat(Color(0.42,0.43,0.41),0.92)
    var grass := _mat(Color(0.12,0.22,0.12),1.0)
    _static_box("Terrain",Vector3(0,-0.35,0),Vector3(150,0.7,150),grass)
    _static_box("MainRoad",Vector3(0,0.02,0),Vector3(16,0.12,145),wet_asphalt,false)
    _static_box("CrossRoad",Vector3(0,0.025,0),Vector3(145,0.12,14),asphalt,false)
    _static_box("SidewalkWest",Vector3(-10,0.16,0),Vector3(4,0.28,145),concrete)
    _static_box("SidewalkEast",Vector3(10,0.16,0),Vector3(4,0.28,145),concrete)

    var line_mat := _mat(Color(0.88,0.78,0.52),0.65)
    for z in range(-68,70,10):
        _static_box("LaneMark",Vector3(0,0.10,z),Vector3(0.18,0.025,4.2),line_mat,false)

    # Shop lots with facade details
    _building("KOPITIAM",Vector3(-19,0,-12),Vector3(12,10,12),Color(0.53,0.36,0.24))
    _building("MINI MART",Vector3(-34,0,-12),Vector3(11,8,12),Color(0.29,0.39,0.43))
    _building("CITY HOTEL",Vector3(28,0,-28),Vector3(17,34,16),Color(0.38,0.43,0.49))
    _building("APARTMENT",Vector3(32,0,12),Vector3(17,23,16),Color(0.56,0.51,0.43))
    _building("OFFICE TOWER",Vector3(-32,0,28),Vector3(18,29,15),Color(0.27,0.37,0.45))
    _building("NIGHT MARKET",Vector3(20,0,34),Vector3(15,7,12),Color(0.44,0.29,0.25))

    # Distant skyline silhouettes
    for i in range(9):
        var x := -58.0 + float(i) * 14.0
        var h := 25.0 + float((i * 13) % 27)
        _building("DistantTower_%d" % i,Vector3(x,0,-62),Vector3(9,h,9),Color(0.23,0.30,0.37),false)

    _street_lamp(Vector3(-12,0,-24))
    _street_lamp(Vector3(12,0,-24))
    _street_lamp(Vector3(-12,0,22))
    _street_lamp(Vector3(12,0,22))
    _palm(Vector3(-13,0,38))
    _palm(Vector3(13,0,42))
    _palm(Vector3(-43,0,4))
    _palm(Vector3(43,0,-2))
    _make_car(Vector3(4,0.35,-19),Color(0.045,0.055,0.07))
    _make_car(Vector3(-4,0.35,22),Color(0.55,0.10,0.07))

    var shop_area := Area3D.new()
    shop_area.position = Vector3(-19,0,-3)
    var area_shape := CollisionShape3D.new()
    var sphere := SphereShape3D.new()
    sphere.radius = 6.0
    area_shape.shape = sphere
    shop_area.add_child(area_shape)
    shop_area.body_entered.connect(_on_shop_enter)
    shop_area.body_exited.connect(_on_shop_exit)
    add_child(shop_area)

func _building(label: String, pos: Vector3, size: Vector3, tint: Color, collision := true) -> void:
    var facade := _mat(tint,0.78,0.05)
    _static_box(label+"_Structure",Vector3(pos.x,size.y/2,pos.z),size,facade,collision)
    var glass := _mat(Color(0.055,0.15,0.21),0.2,0.42)
    var trim := _mat(Color(0.18,0.19,0.20),0.55,0.25)
    _static_box(label+"_RoofTrim",Vector3(pos.x,size.y+0.18,pos.z),Vector3(size.x+0.35,0.36,size.z+0.35),trim,false)
    var floors := int(size.y / 3.2)
    for floor_i in range(floors):
        var y := 1.4 + float(floor_i)*3.1
        _static_box(label+"_FrontGlass_%d" % floor_i,Vector3(pos.x,y,pos.z-size.z/2-0.065),Vector3(size.x*0.72,1.55,0.08),glass,false)
        _static_box(label+"_SideGlass_%d" % floor_i,Vector3(pos.x+size.x/2+0.065,y,pos.z),Vector3(0.08,1.55,size.z*0.72),glass,false)
    if label == "KOPITIAM":
        _static_box("KopitiamSign",Vector3(pos.x,6.8,pos.z-size.z/2-0.18),Vector3(8.0,1.25,0.22),_mat(Color(0.20,0.075,0.035),0.6),false)
        _static_box("ShopAwning",Vector3(pos.x,5.7,pos.z-size.z/2-1.2),Vector3(10,0.28,2.2),_mat(Color(0.55,0.12,0.07),0.7),false)

func _street_lamp(pos: Vector3) -> void:
    _static_box("LampPole",pos+Vector3(0,3,0),Vector3(0.16,6,0.16),_mat(Color(0.08,0.09,0.10),0.45,0.65),false)
    var light := OmniLight3D.new()
    light.position = pos+Vector3(0,5.8,0)
    light.light_color = Color(1.0,0.72,0.43)
    light.light_energy = 1.4
    light.omni_range = 12.0
    add_child(light)

func _palm(pos: Vector3) -> void:
    _static_box("PalmTrunk",pos+Vector3(0,3,0),Vector3(0.45,6,0.45),_mat(Color(0.30,0.20,0.12),0.95),false)
    for angle in range(0,360,60):
        var leaf := MeshInstance3D.new()
        var capsule := CapsuleMesh.new()
        capsule.radius = 0.18
        capsule.height = 5.2
        leaf.mesh = capsule
        leaf.position = pos+Vector3(0,5.4,0)
        leaf.rotation_degrees = Vector3(0,float(angle),62)
        leaf.material_override = _mat(Color(0.10,0.25,0.12),0.9)
        add_child(leaf)

func _make_car(pos: Vector3, color: Color) -> void:
    var root := Node3D.new()
    root.position = pos
    add_child(root)
    var body := MeshInstance3D.new()
    var body_mesh := BoxMesh.new()
    body_mesh.size = Vector3(2.0,0.62,4.1)
    body.mesh = body_mesh
    body.position.y = 0.65
    body.material_override = _mat(color,0.24,0.62)
    root.add_child(body)
    var cabin := MeshInstance3D.new()
    var cabin_mesh := BoxMesh.new()
    cabin_mesh.size = Vector3(1.55,0.72,1.9)
    cabin.mesh = cabin_mesh
    cabin.position = Vector3(0,1.28,-0.15)
    cabin.material_override = _mat(Color(0.045,0.09,0.13),0.12,0.35)
    root.add_child(cabin)
    for x in [-0.88,0.88]:
        for z in [-1.35,1.35]:
            var wheel := MeshInstance3D.new()
            var cyl := CylinderMesh.new()
            cyl.top_radius = 0.38
            cyl.bottom_radius = 0.38
            cyl.height = 0.24
            wheel.mesh = cyl
            wheel.position = Vector3(x,0.38,z)
            wheel.rotation_degrees.z = 90
            wheel.material_override = _mat(Color(0.025,0.025,0.03),0.95)
            root.add_child(wheel)

func _spawn_player(id: int, local: bool) -> void:
    if players.has(id):
        return
    var p := PLAYER_SCENE.instantiate()
    p.name = "Player_%d" % id
    p.set_multiplayer_authority(id)
    p.position = Vector3(0,0.2,5+players.size()*2)
    add_child(p)
    players[id] = p
    if local:
        p.local_player = true

func _peer_connected(id: int) -> void:
    if multiplayer.is_server():
        _spawn_player(id,false)
        _spawn_on_all.rpc(id)

@rpc("authority","call_local","reliable")
func _spawn_on_all(id: int) -> void:
    _spawn_player(id,id == multiplayer.get_unique_id())

func _peer_disconnected(id: int) -> void:
    if players.has(id):
        players[id].queue_free()
        players.erase(id)

func _make_ui() -> void:
    ui = CanvasLayer.new()
    add_child(ui)
    var top := PanelContainer.new()
    top.position = Vector2(16,16)
    top.custom_minimum_size = Vector2(265,110)
    ui.add_child(top)
    var v := VBoxContainer.new()
    top.add_child(v)
    var title := Label.new()
    title.text = "MALAYSIA WORLD  |  KUALA LUMPUR"
    title.add_theme_font_size_override("font_size",16)
    v.add_child(title)
    status_label = Label.new()
    status_label.text = "自由探索 · 吉隆坡市中心"
    v.add_child(status_label)
    money_label = Label.new()
    v.add_child(money_label)
    cafe_label = Label.new()
    v.add_child(cafe_label)
    _refresh_money()

    var joy := Control.new()
    joy.anchor_top = 1.0
    joy.anchor_bottom = 1.0
    joy.position = Vector2(24,0)
    joy.offset_top = -184
    joy.offset_bottom = -24
    joy.custom_minimum_size = Vector2(164,160)
    joy.mouse_filter = Control.MOUSE_FILTER_STOP
    ui.add_child(joy)
    var disk := ColorRect.new()
    disk.position = Vector2(2,2)
    disk.size = Vector2(156,156)
    disk.color = Color(0.04,0.05,0.06,0.38)
    disk.mouse_filter = Control.MOUSE_FILTER_IGNORE
    joy.add_child(disk)
    joy_knob = ColorRect.new()
    joy_knob.position = Vector2(56,56)
    joy_knob.size = Vector2(48,48)
    joy_knob.color = Color(0.82,0.84,0.86,0.82)
    joy_knob.mouse_filter = Control.MOUSE_FILTER_IGNORE
    joy.add_child(joy_knob)
    joy.gui_input.connect(_on_joy)

    var actions := VBoxContainer.new()
    actions.anchor_left = 1.0
    actions.anchor_right = 1.0
    actions.anchor_top = 1.0
    actions.anchor_bottom = 1.0
    actions.offset_left = -174
    actions.offset_right = -18
    actions.offset_top = -240
    actions.offset_bottom = -18
    actions.add_theme_constant_override("separation",8)
    ui.add_child(actions)
    var jump := Button.new()
    jump.text = "跳跃"
    jump.custom_minimum_size = Vector2(150,52)
    jump.button_down.connect(func(): Input.action_press("jump"))
    jump.button_up.connect(func(): Input.action_release("jump"))
    actions.add_child(jump)
    var business := Button.new()
    business.text = "茶室经营"
    business.custom_minimum_size = Vector2(150,52)
    business.pressed.connect(_interact_cafe)
    actions.add_child(business)
    var host := Button.new()
    host.text = "创建联机房间"
    host.custom_minimum_size = Vector2(150,44)
    host.pressed.connect(_host)
    actions.add_child(host)
    address_field = LineEdit.new()
    address_field.placeholder_text = "房主 IP 地址"
    address_field.text = "127.0.0.1"
    address_field.custom_minimum_size = Vector2(150,40)
    actions.add_child(address_field)
    var join := Button.new()
    join.text = "加入房间"
    join.custom_minimum_size = Vector2(150,44)
    join.pressed.connect(_join)
    actions.add_child(join)

func _on_joy(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed:
            joy_id = event.index
            _move_joy(event.position)
        elif event.index == joy_id:
            joy_id = -1
            mobile_move = Vector2.ZERO
            joy_knob.position = Vector2(56,56)
    elif event is InputEventScreenDrag and event.index == joy_id:
        _move_joy(event.position)

func _move_joy(pos: Vector2) -> void:
    var delta := (pos - joy_center).limit_length(joy_radius)
    mobile_move = Vector2(delta.x/joy_radius,delta.y/joy_radius)
    joy_knob.position = joy_center + delta - Vector2(24,24)

func get_move_vector() -> Vector2:
    return mobile_move

func _on_shop_enter(body: Node3D) -> void:
    if body == players.get(multiplayer.get_unique_id()):
        near_cafe = true
        status_label.text = "已到达 Kopitiam 茶室"

func _on_shop_exit(body: Node3D) -> void:
    if body == players.get(multiplayer.get_unique_id()):
        near_cafe = false
        status_label.text = "自由探索 · 吉隆坡市中心"

func _interact_cafe() -> void:
    if not near_cafe:
        status_label.text = "请走到 Kopitiam 茶室门口"
        return
    if not cafe_open:
        if money < 100:
            status_label.text = "资金不足：开店需要 RM100"
            return
        money -= 100
        cafe_open = true
        status_label.text = "茶室开业！每 10 秒接待顾客"
    elif stock <= 0:
        if money >= 30:
            money -= 30
            stock += 10
            status_label.text = "补货成功：库存 +10"
        else:
            status_label.text = "资金不足：补货 RM30"
    else:
        status_label.text = "顾客 %d · 茶室收入 RM%d" % [customers,income]
    _refresh_money()

func _refresh_money() -> void:
    if money_label:
        money_label.text = "钱包：RM %d" % money
    if cafe_label:
        cafe_label.text = "Kopitiam：%s · 库存 %d" % ["营业中" if cafe_open else "未营业",stock]

func _host() -> void:
    peer = ENetMultiplayerPeer.new()
    var err := peer.create_server(PORT,MAX_PLAYERS)
    if err != OK:
        status_label.text = "创建房间失败：" + error_string(err)
        return
    multiplayer.multiplayer_peer = peer
    status_label.text = "房间已创建 · UDP 7777"

func _join() -> void:
    peer = ENetMultiplayerPeer.new()
    var addr := address_field.text.strip_edges()
    if addr.is_empty():
        addr = "127.0.0.1"
    var err := peer.create_client(addr,PORT)
    if err != OK:
        status_label.text = "连接失败：" + error_string(err)
        return
    multiplayer.multiplayer_peer = peer
    status_label.text = "正在连接 " + addr
