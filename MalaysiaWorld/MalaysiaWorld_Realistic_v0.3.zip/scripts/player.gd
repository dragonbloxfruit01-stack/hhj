extends CharacterBody3D

@export var move_speed := 5.2
@export var jump_velocity := 4.3
@export var mouse_sensitivity := 0.003
var gravity := float(ProjectSettings.get_setting("physics/3d/default_gravity"))
var local_player := false
var camera_pivot: Node3D
var touch_move := Vector2.ZERO
var remote_goal := Vector3.ZERO

func _ready() -> void:
    camera_pivot = $CameraPivot
    local_player = is_multiplayer_authority()
    if not local_player:
        $CameraPivot/SpringArm3D/Camera3D.current = false
    remote_goal = global_position

func _unhandled_input(event: InputEvent) -> void:
    if not local_player:
        return
    if event is InputEventScreenDrag:
        camera_pivot.rotate_y(-event.relative.x * mouse_sensitivity)
        camera_pivot.rotation.x = clamp(camera_pivot.rotation.x - event.relative.y * mouse_sensitivity, -0.75, 0.25)
    elif event is InputEventMouseButton and event.pressed:
        Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
    elif event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
        camera_pivot.rotate_y(-event.relative.x * mouse_sensitivity)
        camera_pivot.rotation.x = clamp(camera_pivot.rotation.x - event.relative.y * mouse_sensitivity, -0.75, 0.25)

func _physics_process(delta: float) -> void:
    if not local_player:
        global_position = global_position.lerp(remote_goal, min(delta * 10.0, 1.0))
        return

    if not is_on_floor():
        velocity.y -= gravity * delta
    if Input.is_action_just_pressed("jump") and is_on_floor():
        velocity.y = jump_velocity

    var input_dir := Vector2(
        Input.get_action_strength("move_right") - Input.get_action_strength("move_left"),
        Input.get_action_strength("move_back") - Input.get_action_strength("move_forward")
    )
    var game := get_node_or_null("/root/Main")
    if game and game.has_method("get_move_vector"):
        var pad: Vector2 = game.get_move_vector()
        if pad.length() > 0.08:
            input_dir = pad

    input_dir = input_dir.limit_length()
    var forward := -camera_pivot.global_basis.z
    var right := camera_pivot.global_basis.x
    var dir := (right * input_dir.x + forward * -input_dir.y).normalized()
    if dir.length() > 0.01:
        velocity.x = dir.x * move_speed
        velocity.z = dir.z * move_speed
        $Visual.rotation.y = lerp_angle($Visual.rotation.y, atan2(dir.x, dir.z), delta * 9.0)
    else:
        velocity.x = move_toward(velocity.x, 0.0, 18.0 * delta)
        velocity.z = move_toward(velocity.z, 0.0, 18.0 * delta)
    move_and_slide()

func set_remote_position(pos: Vector3) -> void:
    remote_goal = pos
