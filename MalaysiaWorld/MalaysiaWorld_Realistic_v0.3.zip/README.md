# Malaysia World — Realistic Edition v0.3

写实开放世界方向的 Godot 4 Android 原型。

## 本版变化
- 项目渲染切换为 Godot Mobile Renderer。
- 写实风格材质参数：粗糙度、金属度、玻璃感、湿润路面。
- 吉隆坡街区：商业店铺、办公楼、公寓、远景楼群。
- 路灯、棕榈树、汽车外观、电影感天空和雾效。
- 动态太阳光照时间循环。
- 第三人称人物比例调整，加入衣服/皮肤/裤子材质。
- 手机触屏摇杆、跳跃、茶室经营、RM 虚拟钱包。
- ENet 创建房间和 IP 输入加入入口。

## 导入
使用 Godot 4.3+。导入 `project.godot`，按 F6/F5 运行。
导出 Android APK：安装 Godot Android export templates，配置 Android SDK/JDK，再从 Project > Export 添加 Android preset。

## 重要说明
这是写实风格的程序化灰盒/美术方向原型，不是 GTA 6 级别的最终资产。角色仍是基础几何体，车辆静态展示，城市为小型样板街区。后续需替换专业 PBR 模型、贴图、动画和音效。
联机仍是早期 ENet 骨架，未完成权威服务器、完整同步、账号/数据库和公网部署。跨设备测试需房主 IP 可达并开放 UDP 7777。
RM 为纯虚拟游戏货币，无现实价值。
